<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.html to edit this template
-->
<html>
    <head>
        <title>Aconchego dos Bigodes</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="assets/styles/ruleSet.css" />
        <link rel="stylesheet" type="text/css" href="assets/styles/nav_footer.css" />
    </head>
    <body>
        <?php
        include './banco/sessionInfo/session.php';
        ?>
        <form id="btnSair" action="banco/sessionInfo/session.php" method="post"/></form>

    <nav class="NavBar">
        <div class="center container">
            <ul>
                <li><a class="active" href="#page-top">Home</a></li>
                <li><a href="sobrenos.php">Sobre Nos</a></li>
                <?php
                if ((isset($_SESSION['login']) == false)) {
                    echo "<li style = 'float:right'><a href = './login_cadastro.php'>Cadastre-se</a></li>";
                    echo "<li style = 'float:right'><a href = './login_page.php'>Entrar</a></li>";
                } else {
                    echo "<li style = 'float:right'><a><input class = 'link-button' form = 'btnSair' type = 'submit' value = 'Sair' name = 'btnSair'/> </a></li>";
                    echo "<li style='float:right'><a>$logado</a></li>";
                }

                echo "<li style = 'float:right'><a href = 'database_login.php'>Registros de Login</a></li>";
                ?>

            </ul>
        </div>
    </nav>

    <header class="masthead" id="bemvindo">
        <div class="center container">
            <div class="masthead-subheading">Sejam bem-vindos!</div>
            <div class="masthead-heading text-uppercase">
                Aconchego dos Bigodes Cat Café
            </div>
            <a class="btn botao" href="#services">Saber mais</a>
        </div>
    </header>
   
    <div class="center">TODO write content</div>
    <div class="center">TODO write content</div>
    <div class="center">TODO write content</div>
    <div class="center">TODO write content</div><div class="center">TODO write content</div>


    <footer>
        <div class="container">
            <div class="footer">
                <span>Aconchego dos Bigodes&#174;</span>
            </div>
        </div>
    </footer>

</body>
</html>
