<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Other/html.html to edit this template
-->
<html>
    <head>
        <title>Aconchego dos Bigodes</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" type="text/css" href="assets/styles/ruleSet.css" />
        <link rel="stylesheet" type="text/css" href="assets/styles/nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="assets/styles/sobrenos.css" />
    </head>
    <body>
        <?php
        include './banco/sessionInfo/session.php';
        ?>
        <form id="btnSair" action="banco/sessionInfo/session.php" method="post"/></form>

    <nav class="NavBar">
        <div class="center container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a class="active" href="sobrenos.php">Sobre Nos</a></li>
                <?php
                if ((isset($_SESSION['login']) == false)) {
                    echo "<li style = 'float:right'><a href = './login_cadastro.php'>Cadastre-se</a></li>";
                    echo "<li style = 'float:right'><a href = './login_page.php'>Entrar</a></li>";
                } else {
                    echo "<li style = 'float:right'><a><input class = 'link-button' form = 'btnSair' type = 'submit' value = 'Sair' name = 'btnSair'/> </a></li>";
                    echo "<li style='float:right'><a>$logado</a></li>";
                }
                ?>

            </ul>
        </div>
    </nav>

    <div class="center container">

        <article class="card">
            <div ><img src="assets/imgs/lazaro_animal.jpg" width="180px" alt="..." /></div>
            <h4>Lázaro</h4>
            <div><p>Estudante de Análise e Desenvolvimento de Sistemas, cursando primeiro período.</p>
                <p>E-mail: lazaro.junior@outlook.com</p>
            </div>
        </article>

        <article class="card">
            <div><img src="assets/imgs/Angel.jpeg" width="180px" alt="..." /></div>
            <h4>Matheus Graça</h4>
            <div><p>Estudante de Análise e Desenvolvimento de Sistemas, cursando segundo período. </p>
                <p>"Este é o meu primeiro site, espero que fique bacana!"</p>
                <p>E-mail: Gracafigueiro@outlook.com</p>
            </div>
        </article>

        <article class="card">
            <div><img src="assets/imgs/N.jpg" width="180px"  alt="..." /></div>
            <h4>Nicole P.</h4>
            <div><p class="">Estudante de Análise e Desenvolvimento de Sistemas, cursando segundo período. <br/> E-mail: nicolepsales@gmail.com <br/></p></div>
        </article>

        <article class="card">
            <div><img src="assets/imgs/3.jpg" width="180px" alt="..." /></div>
            <h4>Ruan Caetano</h4>
            <div><p>Estudante de Ciência da Computação, cursando segundo período.</p>
                <p>E-mail: Ruan_b3@hotmail.com</p>
            </div>
        </article>

        <article class="card">
            <div><img src="assets/imgs/rui_animal.jpg" width="180px" alt="..." /></div>
            <h4>Rui Gabriel</h4>
            <div><p>Estudante de Análise e Desenvolvimento de Sistemas, cursando segundo período.</p>
                <p>E-mail: ruigabriel765@gmail.com</p>
            </div>

        </article>

    </div>


    <footer>
        <div class="container">
            <div class="footer">
                <span>Aconchego dos Bigodes&#174;</span>
            </div>
        </div>
    </footer>

</body>
</html>
