/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */

function cadastrarUsuario() {
    const login = document.getElementById('txtLogin').value;
    const senha = document.getElementById('txtSenha').value;
    const confirmaSenha = document.getElementById('txtSenhaCofirm').value;
    if (senha !== confirmaSenha) {
        alert('As senhas não coincidem. Tente novamente.');
        return;
    }

    alert(`Cadastro realizado com sucesso!`);
}


