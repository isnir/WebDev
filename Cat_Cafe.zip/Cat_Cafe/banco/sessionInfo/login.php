<?php
session_start(); //iniciar a sessão
include '../conexao.php';
$login = $_POST['txtLogin'];
$senha = $_POST['txtSenha'];

if (isset($_POST['btnAcessar'])) { //se o botão Acessar foi clicado
    $sql = "SELECT * FROM tblogin WHERE login='$login' AND senha='$senha'";
    if ($con->query($sql)->rowCount() == 0) { //se foram zero registros retornados
        echo "<h3>Login e/ou senha inválidos !!!</h3>";
        echo "<h3><a href='../../login_page.php'>Retornar</a></h3>";
        unset($_SESSION['login']); //desativa o login da sessão
        header("Refresh: 5;url=../../index.php"); //redireciona após 5 segundos
    } else { //validado o login
        $_SESSION['login'] = $login; //armazena na sessão
        header("location:../../index.php"); //redireciona automaticamente
    }
}



/* 
* Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
* Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
*/

